function ProductList({productRevenue}){
return (
    <div>
        <h2>
            Total Revenue for Each Product
        </h2>
        <ul>
            {productRevenue.map((product,index)=>(
                <li key={index}>
                    {product.productName}: ${product.revenue}
                    (Quantity: {product.quantity})
                </li>
            ))}
        </ul>
    </div>
)
}
export default ProductList;