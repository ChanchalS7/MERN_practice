function CategoryList({categoryRevenue}){
return (
    <div>
        <h2>Total Revenue for Each Category</h2>
        <ul>
            {
                Object.keys(categoryRevenue).map((category,index)=>(
                    <li key={index}>
                        {category}:${categoryRevenue[category]}
                    </li>
                ))
            }
        </ul>
    </div>
);
}
export default CategoryList;