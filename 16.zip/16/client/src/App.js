import './App.css';
import {useState,useEffect} from "react";
import ProductList from './components/ProductList';
import CategoryList from './components/CategoryList';
import { API_ROUTES } from './config/api';
function App() {
  const [productRevenue, setProductRevenue]=useState([]);
  const [categoryRevenue,setCategoryRevenue]=useState({})
  const [topSellingProduct,setTopSellingProduct]=useState({})
  const [topSellingCategory,setTopSellingCategory]=useState('');
  useEffect(()=>{
    //fetch product revenue data from the backend api
      fetch(API_ROUTES.PRODUCT_REVENUE)
      .then((response)=>response.json())
      .then((data)=>setProductRevenue(data));

    //fetch category revenue data from the backend api
    fetch(API_ROUTES.CATEGORY_REVENUE)
    .then((response)=>response.json())
    .then((data)=>setCategoryRevenue(data));
    
    //fetch top-selling product data from the backend API
    fetch(API_ROUTES.TOP_SELLING_PRODUCT)
    .then((response)=>response.json())
    .then((data)=>setTopSellingProduct(data))

    //fetch top-selling category data from the backend API
    fetch(API_ROUTES.TOP_SELLING_CATEGORY)
    .then((response)=>response.json())
    .then((data)=>setTopSellingCategory(data))
  },[])
  return (
    <div className="App">
     <h1>Sales Analytics</h1>
     <ProductList productRevenue={productRevenue}/>
     <CategoryList categoryRevenue={categoryRevenue}/>
     <h3>Top-Selling Product</h3>
     {
      topSellingProduct.productName && (
        <p>Product Name: {topSellingProduct.productName}
        <br/>
        Total Revenue : ${topSellingProduct.revenue}
        <br/>
        Quantity Sold : ${topSellingProduct.quantity}
        </p>
      )
     }
     <h3>Top-Selling Category</h3>
     {topSellingCategory && <p>{topSellingCategory}</p>}
    </div>
  );
}

export default App;

/**
 *
 * useEffect(() => {
  // Fetch product revenue data from the backend API using Axios
  axios.get(API_ROUTES.PRODUCT_REVENUE)
    .then((response) => setProductRevenue(response.data))
    .catch((error) => console.error(error));

  // Fetch category revenue data from the backend API using Axios
  axios.get(API_ROUTES.CATEGORY_REVENUE)
    .then((response) => setCategoryRevenue(response.data))
    .catch((error) => console.error(error));

  // Fetch top-selling product data from the backend API using Axios
  axios.get(API_ROUTES.TOP_SELLING_PRODUCT)
    .then((response) => setTopSellingProduct(response.data))
    .catch((error) => console.error(error));

  // Fetch top-selling category data from the backend API using Axios
  axios.get(API_ROUTES.TOP_SELLING_CATEGORY)
    .then((response) => setTopSellingCategory(response.data))
    .catch((error) => console.error(error));
}, []);
 */