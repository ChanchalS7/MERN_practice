const API_BASE_URL='http://localhost:5000/api';
export const API_ROUTES={
    PRODUCT_REVENUE: `${API_BASE_URL}/product-revenue`,
    CATEGORY_REVENUE: `${API_BASE_URL}/category-revenue`,
    TOP_SELLING_PRODUCT: `${API_BASE_URL}/top-selling-product`,
    TOP_SELLING_CATEGORY:`${API_BASE_URL}/top-selling-category`
};